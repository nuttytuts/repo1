import pandas as pd
import csv

def skt_df():
    df = pd.read_csv('songkeytemp.csv')
    print(df)

skt_df()
