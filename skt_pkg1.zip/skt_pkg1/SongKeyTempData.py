import pandas as pd
import csv

def skt_f():
    list1 = []
    list2 = []

    def inputloop():


        input1 = input('songtitle,artist?: ')
        input2 = input('tempo,key?: ')

        list1.append([input1])
        list2.append([input2])

        input3 = input('continue? "y or n"')
        if input3 == 'y':
            return(inputloop())
        if input3 == 'n':
            print(list1)
            print(list2)
        else:
            print('error unknown command')
            pass

    inputloop()

    series1 = pd.Series(list1)
    series2 = pd.Series(list2)
    df = pd.DataFrame({'title,artist' : series1, 'tempo,key' : series2})
    print(df)

    input4 = input('append to csv? "y or n": ')
    if input4 == 'y':
        print(df)
        with open('songkeytemp.csv', 'a') as fa:
            df.to_csv(fa, header=False, index=False)
    else:
        pass

    input5 = input('read full csv data? "y or n": ')
    if input5 == 'y':
        with open('songkeytemp.csv', 'r') as fd:
            print(fd.read())
            quit()
    else:
        print('end')
        quit()
